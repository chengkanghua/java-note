package a.b.c.entity;

import java.io.Serializable;

// 学员
public class User implements Serializable {
    private Integer usr_id; // id
    private String usr_account; // 账户
    private String usr_password; // 密码

    public User() {
    }

    public User(Integer usr_id, String usr_account, String usr_password, Double usr_money) {
        this.usr_id = usr_id;
        this.usr_account = usr_account;
        this.usr_password = usr_password;
    }

    public Integer getUsr_id() {
        return usr_id;
    }

    public void setUsr_id(Integer usr_id) {
        this.usr_id = usr_id;
    }

    public String getUsr_account() {
        return usr_account;
    }

    public void setUsr_account(String usr_account) {
        this.usr_account = usr_account;
    }

    public String getUsr_password() {
        return usr_password;
    }

    public void setUsr_password(String usr_password) {
        this.usr_password = usr_password;
    }

    @Override
    public String toString() {
        return "User{" +
                "usr_id=" + usr_id +
                ", usr_account='" + usr_account + '\'' +
                ", usr_password='" + usr_password +
                '}';
    }
}
