package a.b.c.service;

// 业务
public class UserServiceImpl {
    public void zhuangzhang(int i) {
        System.out.println("A账户减钱");
        System.out.println("B账户加钱");
        //int i = 1 / 0;
        System.out.println("扣除手续费");
    }

    public void yewu1() {
        System.out.println("业务1");
    }

    public void yewu2() {
        System.out.println("业务2");
    }
}
