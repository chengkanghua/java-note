package a.b.c.test;

import a.b.c.service.UserServiceImpl;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo02 {
    @Test
    public void f01() {
        // 搭建了一个spring应用级上下文环境，简称存储对象的容器
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        // 从容器中依据ID获取
        UserServiceImpl userService = (UserServiceImpl) applicationContext.getBean("userService");
        // <? extends UserServiceImpl>，返回的类型必须是UserServiceImpl或它的后代
        Class<? extends UserServiceImpl> aClass = userService.getClass();
        String name = aClass.getName();
        System.out.println("真实的业务对象的全名称：" + name); // a.b.c.service.UserServiceImpl$$EnhancerBySpringCGLIB$$e0b79a7a
        // 展示
        userService.zhuangzhang(1);
        System.out.println();
        userService.yewu1();
        System.out.println();
        userService.yewu2();
    }
}
