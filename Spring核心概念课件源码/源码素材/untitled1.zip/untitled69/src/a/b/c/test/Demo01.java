package a.b.c.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.lang.reflect.Method;

public class Demo01 {
    @Test
    public void f01() throws Exception {
        // a.b.c.entity.User usr_id usr_account usr_password 101 zs 123
        // 利用反射，使用全类名字符串得到对应的字节码对象
        Class<?> objClass = Class.forName("a.b.c.entity.User");
        // 使用简单构造对象方法构建对象
        Object object = objClass.newInstance();
        // 获取set方法
        Method setidMethod = objClass.getMethod("set" + "Usr_id", Integer.class);
        Method setaccountMethod = objClass.getMethod("set" + "Usr_account", String.class);
        Method setpasswordMethod = objClass.getMethod("set" + "Usr_password", String.class);
        // 调用set方法
        setidMethod.invoke(object, 101);
        setaccountMethod.invoke(object, "zs");
        setpasswordMethod.invoke(object, "123");
        // 得到完整的对象
        System.out.println(object);
    }

    @Test
    public void f02() {
        // 搭建了一个spring应用级上下文环境，简称存储对象的容器
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        // 从容器中依据ID获取
        Object user1 = applicationContext.getBean("user1");
        // 展示
        System.out.println(user1);
    }
}
