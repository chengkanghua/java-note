package a.b.c.aop;

// 事务管理类
public class TxManger {
    public void kaiqishiwu() {
        System.out.println("开启事务");
    }

    public void tijiaoshiwu() {
        System.out.println("提交事务");
    }

    public void huigunshiwu() {
        System.out.println("回滚事务");
    }

    public void shifangziyuan() {
        System.out.println("释放资源");
    }
}
