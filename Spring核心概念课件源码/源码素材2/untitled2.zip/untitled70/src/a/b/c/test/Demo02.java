package a.b.c.test;

import a.b.c.entity.Person;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo02 {
    @Test
    public void f01() {
        // 搭建了一个spring应用级上下文环境，简称存储对象的容器
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        // 从容器中依据ID获取
        Person person1 = (Person) applicationContext.getBean("person1");
        // 展示
        System.out.println(person1);
        System.out.println(person1.getHobbys().length);
        System.out.println(person1.getHobbyList().size());
        System.out.println(person1.getHobbyMap().size());
        System.out.println(person1.getCar());
    }
}
