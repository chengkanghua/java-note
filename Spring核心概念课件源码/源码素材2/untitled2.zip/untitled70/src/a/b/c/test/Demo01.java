package a.b.c.test;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo01 {
    @Test
    public void f01() {
        // 搭建了一个spring应用级上下文环境，简称存储对象的容器
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("applicationContext.xml");
        // 从容器中依据ID获取
        Object user1 = applicationContext.getBean("user1");
        Object user11 = applicationContext.getBean("user1");
        // 展示
        System.out.println(user1);
        System.out.println(user11);
        System.out.println(user11==user1);
    }
}
