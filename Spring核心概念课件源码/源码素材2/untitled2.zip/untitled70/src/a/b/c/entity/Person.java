package a.b.c.entity;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class Person {
    private String[] hobbys;
    private List<String> hobbyList;
    private Map<Integer, String> hobbyMap;
    private Car car;

    public String[] getHobbys() {
        return hobbys;
    }

    public void setHobbys(String[] hobbys) {
        this.hobbys = hobbys;
    }

    public List<String> getHobbyList() {
        return hobbyList;
    }

    public void setHobbyList(List<String> hobbyList) {
        this.hobbyList = hobbyList;
    }

    public Map<Integer, String> getHobbyMap() {
        return hobbyMap;
    }

    public void setHobbyMap(Map<Integer, String> hobbyMap) {
        this.hobbyMap = hobbyMap;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    @Override
    public String toString() {
        return "Person{" +
                "hobbys=" + Arrays.toString(hobbys) +
                ", hobbyList=" + hobbyList +
                ", hobbyMap=" + hobbyMap +
                '}';
    }
}
