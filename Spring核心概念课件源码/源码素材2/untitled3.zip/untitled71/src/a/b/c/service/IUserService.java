package a.b.c.service;

public interface IUserService {
    void register();
    void login();
}
