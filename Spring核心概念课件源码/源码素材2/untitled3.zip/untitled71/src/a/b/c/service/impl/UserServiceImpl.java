package a.b.c.service.impl;

import a.b.c.dao.IUserDao;
import a.b.c.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

// 业务
@Component
public class UserServiceImpl implements IUserService {
    @Autowired
    private IUserDao userDao;

    @Override
    public void register() {
        System.out.println("注册，调用dao的新增");
        userDao.insert();
    }

    @Override
    public void login() {
        System.out.println("登录，调用dao的查询");
        userDao.select();
    }
}
