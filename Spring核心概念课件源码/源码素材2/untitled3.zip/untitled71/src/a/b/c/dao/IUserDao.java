package a.b.c.dao;

public interface IUserDao {
    void insert();
    void select();
}
