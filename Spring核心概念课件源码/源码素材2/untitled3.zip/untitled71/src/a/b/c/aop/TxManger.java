package a.b.c.aop;

import org.aspectj.lang.annotation.*;
import org.springframework.stereotype.Component;

// 事务管理类
@Component
@Aspect
public class TxManger {
    @Pointcut("execution(* a.b.c.service.impl.*ServiceImpl.*(..))")
    public void pc() {
    }

    @Before("pc()")
    public void begin() {
        System.out.println("开启事务");
    }

    @AfterReturning("pc())")
    public void commit() {
        System.out.println("提交事务");
    }

    @AfterThrowing("pc())")
    public void rollback() {
        System.out.println("回滚事务");
    }

    @After("pc())")
    public void close() {
        System.out.println("释放资源");
    }
}
