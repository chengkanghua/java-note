package a.b.c.dao.impl;

import a.b.c.dao.IUserDao;
import org.springframework.stereotype.Component;

@Component
public class UserDaoImpl implements IUserDao {
    @Override
    public void insert() {
        System.out.println("新增一行数据");
    }

    @Override
    public void select() {
        System.out.println("查询一行数据");
    }
}
